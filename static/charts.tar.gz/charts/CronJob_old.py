# -*- coding: utf-8 -*-
"""
Created on Sun Dec 30 20:04:54 2018

@author: dj
"""

from django.shortcuts import render
from django.core.paginator import Paginator
from pyignite import Client
import ssl
import json
import csv
from django.http import HttpResponse
from datetime import date, timedelta
import time
import datetime
from django.core.mail import EmailMessage
import os
import glob
from xlsxwriter.workbook import Workbook
from django.http import HttpResponseRedirect
from pyexcel.cookbook import merge_all_to_a_book
import glob

def queryresultalter():
	print("Hello")
	nodes = [
 		('35.154.247.92', 10800),
 		('35.154.247.92', 10801),
	]

	client = Client()
	client.connect(nodes)

	yesterday = "QueryRan"
	print(yesterday)
	startdate = date.today() - timedelta(days=7) - timedelta(hours=5, minutes=30)
	startdate = int((time.mktime(startdate.timetuple()))-19800)
	print("startdate :{}".format(startdate))
	enddate = date.today()
	enddate = int((time.mktime(enddate.timetuple()))-19800)
	print("EndDate :{}".format(enddate))

	# QUERY = ''' SELECT ID, APPID, EVENTS, DEVICE_ID, "TIMESTAMP", MTIMESTAMP, UPTIMESTAMP, IPADDRESS, CITY, COUNTRY, EVENTNAME, CREATED_DATE, CREATED_TIME FROM PUBLIC.EVENTSDATA WHERE "TIMESTAMP" >= '{}' AND "TIMESTAMP" <= '{}' AND EVENTNAME!='_app_crash'; '''.format(startdate,enddate)
	print(QUERY)
	result = client.sql(
		QUERY,
		include_field_names=True,
	)

	print(next(result))

	workbook = Workbook('Data_QueryRan.xlsx')
	worksheet = workbook.add_worksheet()
	lista = ['appid','deviceid','devicemake','devicemodel','platform','apppackage','keyname','mobileoperator','ssid','app','song','album','pstate','source','ipaddress','city','station','duration','timestamp','created_date','created_time']

	r = 0
	c = 0
	for item in lista:
		worksheet.write(r, c, item)
		c = c + 1


	i = 0
	for row in result:
		# print(row)
		if i == 0:
			x = row[2]
			y = json.loads(x)
			if y.get("segmentation") is None:
				ssid = "" if type(y.get("network").get("ssid")) == type(None) else str('"'+y.get("network").get("ssid")+'"')
				ope = "" if type(y.get("network").get("ope")) == type(None) else str('"'+y.get("network").get("ope")+'"')
				lista = [row[1],row[3],'"'+y.get("ma")+'"','"'+y.get("d")+'"','"'+y.get("p")+'"','"'+y.get("ap")+'"','"'+row[10]+'"',ope,ssid,"","","","","",row[7],row[8],"","",row[4],row[11],row[12]]
			else:
				duration = "" if type(y.get("segmentation").get("Duration")) == type(None) else str('"'+y.get("segmentation").get("Duration")+'"')
				station = "" if type(y.get("segmentation").get("Station")) == type(None) and row[10] != "FM_Tuned" else str('"'+y.get("segmentation").get("Station")+'"')
				source = "" if type(y.get("segmentation").get("Source")) == type(None) else str(y.get("segmentation").get("Source"))
				album = "" if type(y.get("segmentation").get("Album")) == type(None) else str('"'+y.get("segmentation").get("Album")+'"')
				song = "" if type(y.get("segmentation").get("Song")) == type(None) else str('"'+y.get("segmentation").get("Song")+'"')
				pstate = "" if type(y.get("segmentation").get("PState")) == type(None) else str('"'+y.get("segmentation").get("PState")+'"')
				app = "" if type(y.get("segmentation").get("App")) == type(None) else str('"'+y.get("segmentation").get("App")+'"')
				print(station)
				ssid = "" if type(y.get("network").get("ssid")) == type(None) else str('"'+y.get("network").get("ssid")+'"')
				ope = "" if type(y.get("network").get("ope")) == type(None) else str('"'+y.get("network").get("ope")+'"')
				lista = [row[1],row[3],'"'+y.get("ma")+'"','"'+y.get("d")+'"','"'+y.get("p")+'"','"'+y.get("ap")+'"','"'+row[10]+'"',ope,ssid,app,song,album,pstate,'"'+source+'"',row[7],row[8],station,duration,row[4],row[11],row[12]]
			i = 1
		else:
			x = row[5]
			try:
				y = json.loads(x)
				if y.get("segmentation") is None:
					ssid = "" if type(y.get("network").get("ssid")) == type(None) else str('"'+y.get("network").get("ssid")+'"')
					ope = "" if type(y.get("network").get("ope")) == type(None) else str('"'+y.get("network").get("ope")+'"')
					lista = [row[1],row[6],'"'+y.get("ma")+'"','"'+y.get("d")+'"','"'+y.get("p")+'"','"'+y.get("ap")+'"','"'+row[2]+'"',ope,ssid,"","","","","",row[10],row[11],"","",row[7],row[3],row[4]]
				else:
					duration = "" if type(y.get("segmentation").get("Duration")) == type(None) else str('"'+y.get("segmentation").get("Duration")+'"')
					station = "" if type(y.get("segmentation").get("Station")) == type(None) and row[2] != "FM_Tuned" else str('"'+y.get("segmentation").get("Station")+'"')
					source = "" if type(y.get("segmentation").get("Source")) == type(None) else str(y.get("segmentation").get("Source"))
					album = "" if type(y.get("segmentation").get("Album")) == type(None) else str('"'+y.get("segmentation").get("Album")+'"')
					song = "" if type(y.get("segmentation").get("Song")) == type(None) else str('"'+y.get("segmentation").get("Song")+'"')
					pstate = "" if type(y.get("segmentation").get("PState")) == type(None) else str('"'+y.get("segmentation").get("PState")+'"')
					app = "" if type(y.get("segmentation").get("App")) == type(None) else str('"'+y.get("segmentation").get("App")+'"')
					ssid = "" if type(y.get("network").get("ssid")) == type(None) else str('"'+y.get("network").get("ssid")+'"')
					ope = "" if type(y.get("network").get("ope")) == type(None) else str('"'+y.get("network").get("ope")+'"')
					lista = [row[1],row[6],'"'+y.get("ma")+'"','"'+y.get("d")+'"','"'+y.get("p")+'"','"'+y.get("ap")+'"','"'+row[2]+'"',ope,ssid,app,song,album,pstate,'"'+source+'"',row[10],row[11],station,duration,row[7],row[3],row[4]]
			except Exception as e:
				print(e)
			i = i + 1
		r = r + 1
		c = 0
		print(lista)
		for item in lista:
			worksheet.write(r, c, item)
			c = c + 1
	workbook.close()
	client.close()
queryresultalter()
